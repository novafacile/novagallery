<?php defined("NOVA") or die(); ?>
{
  "login": "Iniciar sesión",
  "logout": "Cerrar sesión",
  "password": "Contraseña",
  "back": "Retour",
  "404-/-page-not-found": "404 / Página no encontrada",
  "sorry-this-page-does-not-seem-to-be-available": "Lo sentimos, esta página no parece estar disponible.",
  "back-to-home": "Volver a la página de inicio"
}