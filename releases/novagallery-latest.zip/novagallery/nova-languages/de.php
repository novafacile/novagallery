<?php defined("NOVA") or die(); ?>
{
  "login": "Anmelden",
  "logout": "Abmelden",
  "password": "Passwort",
  "back": "Zur&uuml;ck",
  "404-/-page-not-found": "404 / Seite nicht gefunden",
  "sorry-this-page-does-not-seem-to-be-available": "Sorry, dieses Seite scheint nicht zu existieren.",
  "back-to-home": "Zur&uuml;ck zur Startseite"
}