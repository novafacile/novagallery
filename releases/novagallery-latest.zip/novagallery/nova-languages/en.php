<?php defined("NOVA") or die(); ?>
{
  "login": "Login",
  "logout": "Logout",
  "password": "Password",
  "back": "Back",
  "404-/-page-not-found": "404 / Page Not Found",
  "sorry-this-page-does-not-seem-to-be-available": "Sorry, this pages does not seem to be available.",
  "back-to-home": "Back to Home"
}