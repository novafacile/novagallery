<?php
/**
 * Simple Template Object
 * @author novafacile OÜ
 * @copyright Copyright (c) 2021 by novafacile OÜ
 * @license AGPL-3.0
 * @link https://novagallery.org
 **/

class Template {
  public static function render($template){
    require THEME_DIR.'/index.php';
  }

}




?>