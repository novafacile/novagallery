<?php

define('BASE_PATH', ''); // without trailing slash
define('IMAGES_DIR', ROOT_DIR.'/galleries'); // without trailing slash
define('IMAGES_URL', BASE_PATH.'/galleries'); // without domain and trailing slash

?>