<?php
/**
 * Theme "novaGallery Dark" for novaGallery
 * @author novafacile OÜ
 * @copyright Copyright (c) 2021 by novafacile OÜ
 * @license AGPL-3.0
 * @link https://novagallery.org
 **/

require THEME_DIR.'/globals/header.php';
require THEME_DIR.'/'.$template.'.php';
require THEME_DIR.'/globals/footer.php';

?>