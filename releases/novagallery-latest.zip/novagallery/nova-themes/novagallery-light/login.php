    <content class="row mt-5 pt-5">
      <div class="container">
          <form method="post">
            <div class="form-row mt-5">
              <div class="col-12 col-md-6 offset-md-1 col-lg-4 offset-lg-2 mb-3">
                <input type="password" class="form-control" id="password" name="password" placeholder="<?php Language::p('Password'); ?>" required="">
              </div>
              <div class="col-12 col-md-4 mb-5">
                <button type="submit" class="btn btn-secondary offset-lg-1 px-5"><?php Language::p('Login'); ?></button>
              </div>
            </div>
          </form>
      </div>
    </content>