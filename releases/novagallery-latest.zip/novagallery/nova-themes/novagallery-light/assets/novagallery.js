document.addEventListener('DOMContentLoaded', function() {
  var $gallery = new SimpleLightbox('.gallery a', {showCounter:false});
});